module.exports = {
  'secret': 'XWSMeanDevelopment',
  'database': 'mongodb://127.0.0.1/blogApp'
};