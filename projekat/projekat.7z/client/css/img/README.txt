For storing images used by html pages
