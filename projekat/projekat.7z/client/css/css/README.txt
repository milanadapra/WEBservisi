Used for storing css files only
